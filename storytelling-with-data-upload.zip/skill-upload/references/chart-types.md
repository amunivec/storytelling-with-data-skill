# Chart Types Reference

From *Storytelling with Data* by Cole Nussbaumer Knaflic.

---

## Decision Framework

Ask these questions in order:

1. **How many data points?**
   - 1–2 numbers → Simple text
   - Many rows, multiple units → Table or heatmap

2. **What relationship am I showing?**
   - Change over time (continuous) → Line graph
   - Change between two time points → Slopegraph
   - Comparison across categories → Bar chart (horizontal preferred)
   - Part-to-whole → Stacked bar (not pie)
   - Correlation between two variables → Scatterplot
   - Flow / composition change → Waterfall
   - Vastly different magnitudes → Square area

3. **How many series?**
   - 1 series → Single bar or line
   - 2 series → Side-by-side or overlapping line
   - 3+ series → Consider whether all are necessary; de-emphasize non-focus series

---

## Each Chart Type

### Simple Text
**Use when:** You have 1–2 numbers that tell the story on their own.
**Key principle:** Make the number large; add a short sentence of context.
**Avoid:** Putting 1–2 numbers in a bar chart — they lose impact.

---

### Table
**Use when:** Your audience needs to look up their own row of interest, or you
have multiple units of measure.
**Key principle:** Design should fade into background — light or no borders,
data stands out, not structure.
**Avoid:** Tables in live presentations (audience reads instead of listening).
**Tip:** Push heavy borders to grey or remove; use white space to separate rows.

---

### Heatmap
**Use when:** Same as table, but you want to add a visual layer to help the
eye quickly find highs and lows.
**Key principle:** Use single-color saturation scale (darker = higher or lower).
Always include a legend.
**Avoid:** Rainbow color scales — preattentive value is lost when everything differs.

---

### Line Graph
**Use when:** Data is continuous (usually time-based). The line implies
connection between points.
**Key principle:** Time on x-axis must be in consistent intervals.
Non-zero baseline is acceptable (unlike bar charts), but use caution — make
it obvious and don't exaggerate small changes.
**Avoid:** Using lines for categorical data (the implied connection is misleading).
**Variants:**
- Single series, two series, multiple series
- Add range/confidence band to show min/avg/max
- Annotated line graph: add text callouts to explain notable points
- Forecast variant: solid line for actual, dotted for forecast; shade forecast area

---

### Slopegraph
**Use when:** You have exactly two time points or comparison points and want
to show relative increases/decreases across categories.
**Key principle:** The slope of the line communicates rate of change intuitively —
no explanation needed.
**Avoid:** When many lines overlap (consider highlighting just one at a time).

---

### Vertical Bar Chart
**Use when:** Categorical data where you want to compare values.
**Key principle:** ALWAYS zero baseline. Bar width should be wider than
the gaps between bars.
**Avoid:** More than ~3 series (too cluttered); non-zero baseline (misleading).
**Tip:** Use single series or two series; with multiple series, visual grouping
becomes important — order categories to ease comparison.

---

### Stacked Vertical Bar Chart
**Use when:** You want to show totals AND subcomponents simultaneously.
**Key principle:** Only the bottom series and total height are easy to compare;
middle series comparisons are hard (no consistent baseline).
**Avoid:** Too many subcomponent categories; use sparingly.
**Variants:** Absolute stacked bars vs. 100% stacked bars (choose based on
whether totals matter).

---

### Waterfall Chart
**Use when:** You want to show a starting value, a series of additions/
subtractions, and an ending value.
**Key principle:** Floating bars show the incremental changes. Great for
"headcount math," budget changes, or profit bridges.
**Tip:** If your tool doesn't have a native waterfall, use stacked bars with the
bottom series set to invisible.

---

### Horizontal Bar Chart
**Use when:** Categorical comparison — especially when category names are long.
**Key principle:** Audiences read left-to-right; they see the category name
before the bar, so they know what they're looking at before the data.
Z-pattern eye movement means top of chart is seen first — put the most
important category there.
**Prefer over vertical** for: ranked lists, long category labels, many categories.
**Ordering:** Descending by value unless there's a natural ordering (e.g., age groups).

---

### Stacked Horizontal Bar Chart
**Use when:** Survey Likert data (strongly disagree → strongly agree) or any
negative-to-positive scale. The 100% stacked horizontal gives consistent
baselines on both left and right ends, making extremes easy to compare.
**Key principle:** Order categories meaningfully; the left-most and right-most
series are easiest to compare.

---

### Scatterplot
**Use when:** You want to show the relationship (correlation) between
two variables.
**Key principle:** x-axis and y-axis both encode data simultaneously. Add an
average reference line to give context. Use color to highlight a subset.
**Avoid:** In presentations to non-technical audiences without good setup.

---

### Square Area Graph
**Use when:** You need to compare numbers of vastly different magnitudes
and a single dimension (bar chart) would require impractical scale.
**Key principle:** The second dimension allows compact comparison. Use
sparingly — people are not great at comparing 2D areas.

---

## Charts to Avoid

### Pie Chart ❌
**Why:** Human vision cannot accurately attribute quantitative value to angles
or 2D slices. When slices are close in size, you can't tell which is bigger.
When they differ, you can estimate one is bigger but not by how much.
The 3D pie is worse — perspective distortion further skews perception.
**Instead:** Horizontal bar chart, ordered from largest to smallest.

### Donut Chart ❌
**Why:** Requires comparing arc lengths — even harder than comparing pie
angles. No quantitative value can be reliably attributed to arc length.
**Instead:** Horizontal bar chart.

### 3D Charts ❌
**Why:** 3D introduces perspective that distorts values. In Excel, bar heights
in 3D are determined by a tangent plane — meaning the plotted bar height
does not correspond to the actual value. A bar worth 1 unit reads visually as
0.8. Side and floor panels add clutter with zero informational value.
**Rule:** Never use 3D to plot a single dimension. The only valid 3D use case
is plotting three actual dimensions — which is rare and still tricky.

### Secondary Y-Axis ❌
**Why:** Forces audience to decode which data belongs to which axis.
Implicitly suggests a relationship between two datasets that may not exist.
**Instead:**
- Option 1: Label the second series' data points directly (no right axis needed)
- Option 2: Split into two separate charts sharing the same x-axis
- Option 3: Use color to link the axis title to the data (least preferred)
