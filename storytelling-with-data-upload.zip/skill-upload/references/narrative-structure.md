# Narrative Structure

From *Storytelling with Data* by Cole Nussbaumer Knaflic.

Use this reference when the user is building a full data presentation,
report, or communication — not just a single chart.

---

## The Fundamental Shift

Most people show data. The goal is to tell a story with data.

The difference:
- **Showing data:** "Here are the numbers. Draw your own conclusions."
- **Telling a story:** "Here is what the data means, why it matters to you,
  and exactly what I need you to do about it."

Conflict and tension are not problems to avoid — they are the engine of story.
Without tension (a problem, a gap, a decision to make), there is no story,
only a report.

---

## Step 1 — Build the Big Idea

The Big Idea is a single sentence that contains the entire story.
It must satisfy three criteria simultaneously:

1. **States your unique point of view** — not just what the data shows,
   but what *you* think it means
2. **Conveys what's at stake** — why the audience should care; what is
   at risk or possible
3. **Is a complete sentence** — not a topic or a title

**Template:**
> [The data shows / We found that] [specific situation or trend], and because of
> this [what's at stake], therefore we recommend [specific action].

**Examples:**

| Weak (descriptive) | Strong (Big Idea) |
|---|---|
| "Q3 Revenue Performance" | "Revenue fell 18% in Q3 due to APAC churn, and we will miss annual targets unless we intervene in October." |
| "Customer Satisfaction Survey Results" | "Satisfaction scores improved overall, but the 18–25 segment declined sharply — if unaddressed, we risk losing our fastest-growing cohort." |
| "Staffing Analysis" | "Our team processed 23% fewer tickets in H2 due to attrition; approving two hires now will prevent further SLA breaches." |

If you can't write a Big Idea, the story isn't ready. Go back to the data.

---

## Step 2 — Write the 3-Minute Story

The 3-minute story is what you'd say if someone in an elevator asked
what you're working on. It's a verbal rehearsal of the story stripped to
its essentials.

It forces you to know:
- The most important pieces (what to keep)
- What isn't essential (what to cut)

Writing it out before building slides prevents over-including data.

**Structure of the 3-minute story:**
1. The situation (context / background)
2. The complication (what changed or is at risk)
3. The question (what the audience needs to decide)
4. The answer / recommendation
5. The supporting evidence (the data — briefly)

---

## Step 3 — Storyboard Before You Build

Do not open PowerPoint, Tableau, or any tool until you have a storyboard.

**Why:** Once you've built something on a computer, you become attached to it.
You'll resist cutting things you spent time creating even when you know
you should cut them. Starting on paper or sticky notes avoids this.

**How to storyboard:**
- Use sticky notes, whiteboard, or blank paper
- One sticky note = one slide or one idea
- Write the headline (action title) for each note — not the content
- Arrange them in sequence; move them around freely until the flow feels right
- Don't start building until the sequence makes sense as a story

**Test:** Can you read just the sticky note headlines left-to-right and
understand the full story? If yes, the structure is right.

---

## Step 4 — Structure the Narrative (Three Acts)

### Act 1 — The Setup
Establish the world as it is. Answer:
- **Setting:** When and where does this story take place?
- **Main character:** Who is driving the action? (Frame in terms of the *audience*, not yourself)
- **The imbalance:** What has changed, gone wrong, or is at risk?
- **The desired balance:** What should the world look like if things go right?
- **The solution:** How will you get there?

Keep this short. The audience needs context but not everything you know.
Resist the urge to show all your exploratory work here.

### Act 2 — The Middle (Conflict / Evidence)
Develop the story and convince the audience. Include:
- Supporting data that demonstrates the problem
- External context or comparison points that give the data meaning
- Consequences of inaction (what happens if nothing changes)
- Options considered (shows rigor; makes your recommendation feel earned)
- The case for your recommended solution

Ask: what motivates this audience? Money? Risk? Competition? Growth?
Frame the evidence in terms of what they care about.

### Act 3 — The End (Resolution / Call to Action)
End with one clear ask. Never let the audience leave without knowing
exactly what you need from them.

- State the call to action explicitly: "We need you to approve X by Y date"
- Tie back to the imbalance you introduced in Act 1
- Create urgency if genuine: "If we delay past [date], [consequence]"

---

## Narrative Flow Options

### Chronological (default)
Tell the story in the order you experienced it:
problem identified → data gathered → analysis → finding → recommendation.

**Use when:** You need to establish credibility, the audience cares about your
process, or they're skeptical and need to see the work before accepting the conclusion.

### Lead With the Ending
Start with the call to action. Then back into the evidence.

**Use when:** Audience is busy or impatient, you've already established trust,
they just need the "so what" and not the "how we got there."

**How to signal this to the audience:**
> "I'm going to start with what we're asking of you, then walk you through the
> analysis that led us here."

This prevents confusion about why you're starting at the conclusion.

---

## Bing, Bang, Bongo (Repetition Framework)

Tell them what you'll say → say it → summarize what you said.

| Stage | In a presentation | In a written report |
|---|---|---|
| **Bing** | Executive summary slide at the start | Executive summary section |
| **Bang** | The main content slides | The body of the report |
| **Bongo** | Summary / next steps slide at the end | Conclusion section |

This feels redundant to the presenter who wrote it. It feels clear and
respectful to the audience hearing it for the first time.

---

## Four Story Structure Tests

Run these after building the full presentation:

### 1. Horizontal Logic Test
Read only the slide titles, left-to-right. Together, do they tell the
complete story you want to communicate?

If no: the titles are descriptive, not action-oriented. Rewrite them.

**Descriptive title:** "Q3 Sales by Region"
**Action title:** "APAC drove 80% of Q3 growth; all other regions were flat"

### 2. Vertical Logic Test
On each individual slide: does every element reinforce the title?
Is there anything on the slide that doesn't support what the title says?

If no: remove the unrelated content, or split into two slides.

### 3. Reverse Storyboard Test
Take your finished deck. Write down the main point of each slide on
a separate piece of paper. Read the list. Does it match the story
you intended to tell?

If no: the deck has drifted from your story. Find where it went off-track.

### 4. Fresh Perspective Test
Hand the deck to someone who hasn't seen it. Ask them:
- Where does your attention go first on each slide?
- What do you think I'm trying to tell you?
- Where do you have questions?
- What's the one thing you'd remember tomorrow?

Their answers will surface gaps you can't see because you're too close to the content.

---

## Spoken vs. Written Narrative

| Presentation (spoken) | Circulated report (written) |
|---|---|
| Slides can be sparse — you fill in the words | Slides / pages must stand alone without you |
| You control pacing and can respond to reactions | Reader controls pacing and may skip around |
| Less detail needed on the slide | More detail needed on the page |
| Can clarify questions in real time | Must anticipate and address questions in text |

**The slideument problem:** When one document tries to do both jobs, it
does neither well — too dense for presenting, not detailed enough for reading.
When possible, create two versions. When you can't, design for the primary use case
and acknowledge the trade-off.

---

## Consulting for Context (Questions to Ask Stakeholders)

When building a communication for someone else's data or request,
get these answers before building anything:

1. What background information is relevant?
2. Who is the audience and what do we know about them?
3. What biases does the audience have — will they be resistant or supportive?
4. What data is available? Is the audience familiar with it?
5. Where are the risks — what could weaken our case?
6. What does success look like?
7. If you had one sentence, what would you say?
8. If you had three minutes, what would you say?

Questions 7 and 8 are the most valuable. They force the requester to
prioritize and often surface the real story faster than anything else.
