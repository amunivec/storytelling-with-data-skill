# Critique Mode

Use this reference when the user shares an existing chart, dashboard, slide,
or visualization and asks Claude to audit, improve, or give feedback on it.

---

## When to Activate Critique Mode

Trigger phrases include:
- "What's wrong with this chart?"
- "How can I improve this?"
- "Is this a good visualization?"
- "Can you give me feedback on this?"
- "Redesign this chart"
- "Make this better"
- Any upload of a chart image with a question attached

---

## Critique Protocol

Run these checks in order. Report findings grouped by severity:
**Critical** (actively misleads) → **Significant** (creates unnecessary confusion)
→ **Minor** (polish / preference).

Always end with a concrete, prioritized list of recommended changes.

---

### CHECK 1 — Context (is the purpose clear?)

- Can you tell **who** this is for and **what** they're supposed to do with it?
- Is there an action title (tells you the insight) or just a descriptive title
  (tells you the topic)?
- Is there a clear call to action, or does the chart just show data?

**Flag if:** Title is purely descriptive (e.g., "Q3 Revenue by Region" instead of
"Revenue declined 18% in Q3, driven by APAC").

---

### CHECK 2 — Chart Type (right tool for the job?)

Ask: does the chosen chart type make the intended comparison easy?

| If the chart uses... | Check whether... |
|---|---|
| Pie or donut | The comparison can be made without angles — almost always yes → flag |
| 3D | Any dimension — always flag; 3D distorts perception |
| Bar chart | Baseline is zero — if not, flag as Critical |
| Line chart | Data is continuous (time-based) — if categorical, flag |
| Stacked bars | Middle segments need to be compared — if yes, this is hard; flag |
| Secondary y-axis | Two axes are present — flag and suggest alternatives |
| Multiple colors | Each color carries distinct meaning — if color = decoration, flag |

---

### CHECK 3 — Clutter Inventory

Scan for each of the following and flag any that are present without
adding informational value:

- [ ] Chart border / frame around the plot area
- [ ] Background shading or fill color (non-white)
- [ ] Gridlines (heavy or dark)
- [ ] Data markers on every point of a line graph
- [ ] Trailing zeros (e.g., `100.00` instead of `100`)
- [ ] Diagonal axis labels (rotated text)
- [ ] Legend that could be replaced by direct labels
- [ ] Duplicate information (same data in both axis and data label)
- [ ] Units repeated on every tick mark when once (in axis title) would suffice
- [ ] Drop shadows, bevels, glows on bars or text
- [ ] Center-aligned text blocks
- [ ] Decorative icons or images that don't encode data

---

### CHECK 4 — Attention and Hierarchy

- Where does your eye go **first**? Is that where the most important
  information is?
- Is there **one** dominant visual element, or does everything compete equally?
- Does color carry meaning, or is it decorative / default rainbow?
- Is there a clear visual hierarchy: most important → supporting → context?

**Flag if:**
- Everything is the same color (no hierarchy)
- The most important data point is not visually distinct
- Multiple things fight for attention simultaneously
- Color choices appear to be tool defaults (Excel default blue/orange/grey palette),
  not intentional decisions

---

### CHECK 5 — Accessibility and Text

- Does every chart have a **title**?
- Does every axis have a **label**?
- Are units explicit? (%, $, count, index — never ambiguous)
- Is there a data source noted?
- Is the font size legible at the intended viewing distance / screen size?
- Are there any rotated labels that could be horizontal?
- Is the takeaway stated explicitly in words, or left for the audience to infer?

**Flag if:** Any of the above are missing.

---

### CHECK 6 — Ethical / Accuracy Issues (Critical)

These are the most severe findings — flag immediately and clearly:

- **Non-zero baseline on bar chart** — visually inflates differences
- **Truncated y-axis on bar chart** — same issue
- **Inconsistent time intervals on x-axis** (e.g., monthly then yearly) — misleading rate of change
- **Cherry-picked time range** that hides context
- **Missing denominator** (showing counts when rates are more meaningful, or vice versa)
- **Implied causation from correlation** in the chart title or annotation
- **3D perspective that distorts relative values**

---

## Critique Output Format

Structure feedback like this:

```
## Chart Audit

**Critical Issues (fix these first)**
1. [Issue] — [Why it misleads] — [Specific fix]

**Significant Issues (meaningfully improve comprehension)**
2. [Issue] — [Why it causes confusion] — [Specific fix]

**Minor Polish**
3. [Issue] — [Fix]

**What's Working**
- [Genuine strengths — don't skip this]

**Recommended Priority Order**
1. [Most impactful fix]
2. ...
```

Never skip "What's Working." Every chart has something worth acknowledging,
and the feedback will land better if it's not purely negative.

---

## Redesign Guidance (when asked to improve, not just critique)

When the user wants a redesign — not just feedback — follow this sequence:

1. **State the principle violated** before proposing the fix
   (e.g., "This uses a pie chart, which makes it impossible to accurately
   compare slices — a horizontal bar chart will make the comparison immediate.")

2. **Propose the new chart type and layout** in plain language first,
   before any code or mockup

3. **Ask if there are constraints** — tool they must use, brand colors,
   audience that expects a specific format — before finalizing the redesign

4. **Explain trade-offs** if the redesign loses something the original had
   (e.g., "Switching from stacked to grouped bars makes individual series
   easier to compare, but you lose the sense of total magnitude")

5. **Deliver the redesign** with inline comments explaining each decision
   (especially color choices, what was removed, and why)

---

## Tool-Specific Critique Notes

### Excel / Power BI
Common default settings to flag:
- Chart borders (on by default in older Excel)
- Gridlines that are too heavy or dark
- 3D chart types in the chart gallery (tempting; always wrong)
- Default rainbow color palette (no hierarchy)
- Legend placed at bottom requiring eye travel back-and-forth

### R (ggplot2)
- Default grey background (`theme_grey`) — replace with `theme_minimal()` or `theme_classic()`
- Default legend position is right — often better to label directly
- Default axis titles use column names — always override with human-readable labels
- Rotated x-axis labels — consider `coord_flip()` for horizontal bars

### Python (matplotlib/seaborn)
- Default color cycle (blue/orange/green/red) creates false visual hierarchy
- Default figure size is small — explicitly set for legibility
- Default tick formatting may include trailing decimals

### Tableau / Power BI dashboards
- Watch for "dashboard clutter" — too many charts trying to tell too many stories
  simultaneously; each dashboard should have one primary question it answers
- Tooltips that add data not in the visual — useful but can hide important context
  that should be in the chart itself
- Default colors in both tools default to categorical rainbows — override intentionally
