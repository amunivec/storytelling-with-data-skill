# Color Guide

From *Storytelling with Data* by Cole Nussbaumer Knaflic.

---

## Core Philosophy

Color is the most powerful preattentive attribute you have. It is also the most
abused. The rules:

1. **Use color sparingly** — maximum 1–2 highlight colors; everything else grey
2. **Use color consistently** — the same color should mean the same thing throughout
3. **Design with colorblind users in mind** — ~8% of men, ~0.5% of women
4. **Be intentional** — never let the tool choose your color palette

The effect: when everything is grey and one element is blue, the eye goes
straight to the blue. When everything is a different color, nothing stands out —
you've recreated the "count the 3s" problem.

---

## Default Palette

| Role | Color | Hex | Notes |
|------|-------|-----|-------|
| Base / background | Light grey | `#D3D3D3` or `#CCCCCC` | For gridlines, axes, de-emphasized elements |
| Non-focus data | Medium grey | `#999999` or `#888888` | For comparison series, context data |
| Chart text (titles, labels) | Dark grey | `#595959` or `#404040` | Softer than black; preserves black for emphasis |
| Primary emphasis | Medium blue | `#1F77B4` or `#2196F3` | Standout color; colorblind-safe; prints well in B&W |
| Pure black | `#000000` | Reserve for maximum emphasis only |

---

## Positive / Negative Palette (colorblind-safe)

Avoid red/green combinations — the most common form of colorblindness.

| Meaning | Color | Hex |
|---------|-------|-----|
| Positive / good | Blue | `#1F77B4` |
| Negative / bad | Orange | `#FF7F0E` |

If you must use red and green (e.g., brand requirement), add a secondary
visual cue: bold, plus/minus sign, or different pattern.

---

## What Color Communicates

Color carries meaning before the audience reads a single word:

- **Red** → danger, loss, urgent, negative
- **Green** → success, growth, positive
- **Blue** → neutral, calm, professional, trustworthy
- **Orange** → caution, warmth, attention
- **Grey** → background, de-emphasis, secondary
- **Yellow** → attention (especially on dark backgrounds); rarely used on white

Match color tone to communication tone. A quarterly business review is not
the same as a marketing infographic — use palette accordingly.

---

## Color Consistency Rules

- If you use blue for Product A on slide 3, blue = Product A on every subsequent slide
- Changing color signals a change in meaning — don't change it for variety
- If a topic or section shifts, a color change can visually reinforce the transition

---

## Colorblind Considerations

~8% of men have red-green colorblindness (deuteranopia/protanopia).
Test your visuals with a colorblindness simulator:

- **Coblis** — coblis.com
- **Color Oracle** — colororacle.org (desktop app, full-screen filter)
- **Viz Palette** — projects.susielu.com/viz-palette

Safe pairings:
- Blue + Orange ✓
- Blue + Grey ✓
- Black + Yellow ✓ (especially on dark backgrounds)
- Red + Green ✗ (avoid)

---

## Dark Background Considerations

Default recommendation: white background.

If a dark background is required (client brand, template):
- Invert the rule: the further a color is from black, the more it stands out
- White text on dark = high contrast (use sparingly for emphasis)
- Grey text on dark = de-emphasis
- Yellow on black = very high attention (use only for the key callout)
- Avoid dark green or dark red — they blend into dark backgrounds

---

## Rainbow / Multi-Color Danger Zone

Using 10 different colors to represent 10 categories destroys preattentive value.
When everything is different, nothing stands out.

**Bad:** 10 categories, each a color of the rainbow
**Good:** 1 highlighted category in blue, 9 de-emphasized in grey

If you need to differentiate many categories, use:
- Varying saturation of a single color (heatmap approach)
- Grey shades with labels directly on the data
- Highlight one at a time across multiple views of the same chart

---

## Brand Colors

When working within brand constraints:
1. Identify 1–2 brand colors that can serve as your "look here" signal
2. Keep everything else grey / muted
3. If brand colors are too light or washed out for contrast, use bold black as emphasis instead
4. If brand colors clash with the message tone, discuss with the client — sometimes a deviation is warranted
