# Code Templates

Clean, SWD-compliant chart starters for common libraries.
Apply these as a base — customize colors, labels, and annotations for the specific use case.

---

## Matplotlib (Python)

### Base style setup (run once per session)
```python
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

# SWD-compliant defaults
plt.rcParams.update({
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.spines.left': False,     # Remove if labeling data directly
    'axes.spines.bottom': True,
    'axes.grid': False,
    'axes.facecolor': 'white',
    'figure.facecolor': 'white',
    'font.family': 'sans-serif',
    'font.size': 11,
    'axes.titlesize': 13,
    'axes.titleweight': 'normal',
    'axes.titlecolor': '#404040',
    'axes.labelcolor': '#595959',
    'xtick.color': '#595959',
    'ytick.color': '#595959',
    'axes.edgecolor': '#CCCCCC',
})

# Color palette
GREY = '#999999'
DARK_GREY = '#595959'
BLUE = '#1F77B4'      # Primary emphasis color
ORANGE = '#FF7F0E'    # Secondary / negative emphasis
```

---

### Horizontal bar chart (recommended for categorical comparison)
```python
import matplotlib.pyplot as plt
import numpy as np

categories = ['Category A', 'Category B', 'Category C', 'Category D', 'Category E']
values = [87, 64, 52, 41, 33]

# Sort descending (most important first — top of chart)
sorted_pairs = sorted(zip(values, categories), reverse=True)
values_sorted, cats_sorted = zip(*sorted_pairs)

fig, ax = plt.subplots(figsize=(8, 5))

# Grey bars for all, blue for the one that matters
colors = [BLUE if i == 0 else GREY for i in range(len(cats_sorted))]
bars = ax.barh(cats_sorted, values_sorted, color=colors, height=0.6)

# Direct labels on bars (no y-axis needed)
for bar, val in zip(bars, values_sorted):
    ax.text(bar.get_width() + 1, bar.get_y() + bar.get_height() / 2,
            f'{val}%', va='center', ha='left', color=DARK_GREY, fontsize=10)

# Remove clutter
ax.set_xlim(0, max(values_sorted) * 1.15)
ax.spines['left'].set_visible(False)
ax.spines['bottom'].set_visible(False)
ax.xaxis.set_visible(False)   # No axis needed — values labeled directly
ax.tick_params(left=False)

# Titles
ax.set_title('Category A leads on [Metric]\n', loc='left', color='#404040', fontsize=13)

plt.tight_layout()
plt.savefig('chart.png', dpi=150, bbox_inches='tight')
plt.show()
```

---

### Line graph (time series)
```python
import matplotlib.pyplot as plt
import pandas as pd

# Assume df has columns: 'date', 'series_a', 'series_b'
fig, ax = plt.subplots(figsize=(10, 5))

# De-emphasized series in grey
ax.plot(df['date'], df['series_b'], color=GREY, linewidth=1.5, label='_nolegend_')

# Focus series in blue — thicker
ax.plot(df['date'], df['series_a'], color=BLUE, linewidth=2.5, label='_nolegend_')

# Direct labels at end of lines (no legend)
last = df.iloc[-1]
ax.text(last['date'], last['series_a'] + 1, 'Series A',
        color=BLUE, fontsize=10, va='bottom')
ax.text(last['date'], last['series_b'] - 1, 'Series B',
        color=GREY, fontsize=10, va='top')

# Annotate a notable point
# ax.annotate('Event happened here', xy=(event_date, event_value),
#             xytext=(event_date, event_value + 10),
#             arrowprops=dict(arrowstyle='->', color=DARK_GREY),
#             color=DARK_GREY, fontsize=9)

# Remove clutter
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['left'].set_color('#CCCCCC')
ax.spines['bottom'].set_color('#CCCCCC')
ax.tick_params(colors='#595959')

# Titles
ax.set_title('Action title that states the insight\n', loc='left',
             color='#404040', fontsize=13)
ax.set_ylabel('Metric name', color='#595959', fontsize=10)
ax.set_xlabel('Time period', color='#595959', fontsize=10)

# Source footnote
fig.text(0, -0.02, 'Source: [data source]', fontsize=8, color='#999999')

plt.tight_layout()
plt.show()
```

---

### Vertical bar chart (with zero baseline enforced)
```python
fig, ax = plt.subplots(figsize=(8, 5))

x = range(len(categories))
colors = [BLUE if i == highlight_index else GREY for i in x]

ax.bar(x, values, color=colors, width=0.6)
ax.set_xticks(x)
ax.set_xticklabels(categories, color=DARK_GREY)

# ALWAYS start at zero
ax.set_ylim(0, max(values) * 1.15)

# Remove top and right spines
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['left'].set_color('#CCCCCC')

ax.set_title('Action title\n', loc='left', color='#404040', fontsize=13)
ax.set_ylabel('Metric', color='#595959')

plt.tight_layout()
plt.show()
```

---

## Seaborn (Python)

Seaborn builds on matplotlib. Apply the same rcParams from above first.

```python
import seaborn as sns

# Override seaborn defaults to match SWD style
sns.set_theme(style='white', palette=['#1F77B4', '#999999', '#FF7F0E'])

# Horizontal bar (seaborn)
fig, ax = plt.subplots(figsize=(8, 5))
sns.barplot(data=df, x='value', y='category', orient='h',
            palette=[BLUE if i == 0 else GREY for i in range(len(df))],
            ax=ax)

# Remove default legend, add direct labels
ax.legend_.remove() if ax.legend_ else None
for i, v in enumerate(df['value']):
    ax.text(v + 0.5, i, f'{v}', va='center', color=DARK_GREY)

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.set_title('Action title', loc='left')
```

---

## Plotly (Python — interactive)

```python
import plotly.graph_objects as go

# SWD-compliant plotly layout template
swd_layout = dict(
    plot_bgcolor='white',
    paper_bgcolor='white',
    font=dict(family='Arial, sans-serif', color='#595959'),
    title=dict(x=0, font=dict(size=14, color='#404040')),
    xaxis=dict(showgrid=False, linecolor='#CCCCCC', tickcolor='#CCCCCC'),
    yaxis=dict(showgrid=False, linecolor='#CCCCCC', tickcolor='#CCCCCC',
               zeroline=False),
    showlegend=False,   # Use direct annotations instead
)

# Horizontal bar chart
fig = go.Figure()

for i, (cat, val) in enumerate(zip(categories, values)):
    color = '#1F77B4' if i == 0 else '#999999'
    fig.add_trace(go.Bar(
        x=[val], y=[cat],
        orientation='h',
        marker_color=color,
        text=[f'{val}%'],
        textposition='outside',
        showlegend=False,
    ))

fig.update_layout(
    **swd_layout,
    title='Action title here',
    barmode='relative',
    yaxis=dict(autorange='reversed'),  # Most important at top
)
fig.show()
```

---

## D3.js (JavaScript)

```javascript
// SWD color constants
const BLUE = '#1F77B4';
const GREY = '#999999';
const DARK_GREY = '#595959';
const LIGHT_GREY = '#CCCCCC';

// Standard margins — preserves white space
const margin = { top: 40, right: 20, bottom: 50, left: 120 };
const width = 600 - margin.left - margin.right;
const height = 400 - margin.top - margin.bottom;

const svg = d3.select('#chart')
  .append('svg')
  .attr('width', width + margin.left + margin.right)
  .attr('height', height + margin.top + margin.bottom)
  .append('g')
  .attr('transform', `translate(${margin.left},${margin.top})`);

// Remove chart border (no rect around the whole chart)

// Axes: light grey, no heavy lines
svg.append('g')
  .call(d3.axisLeft(yScale)
    .tickSize(0)
    .tickPadding(8))
  .call(g => g.select('.domain').attr('stroke', LIGHT_GREY))
  .call(g => g.selectAll('text').attr('fill', DARK_GREY).attr('font-size', '11px'));

// No gridlines — or if needed, make them thin and light grey
// svg.append('g').attr('class', 'grid')
//   .call(d3.axisLeft(yScale).tickSize(-width).tickFormat(''))
//   .call(g => g.selectAll('line').attr('stroke', LIGHT_GREY).attr('stroke-width', 0.5))
//   .call(g => g.select('.domain').remove());

// Direct labels instead of legend
svg.selectAll('.bar-label')
  .data(data)
  .enter()
  .append('text')
  .attr('x', d => xScale(d.value) + 4)
  .attr('y', d => yScale(d.category) + yScale.bandwidth() / 2)
  .attr('dy', '0.35em')
  .attr('fill', DARK_GREY)
  .attr('font-size', '11px')
  .text(d => d.value);
```

---

## Chart.js (JavaScript)

```javascript
const ctx = document.getElementById('myChart').getContext('2d');

// SWD defaults — pass as global defaults before creating charts
Chart.defaults.color = '#595959';
Chart.defaults.font.family = 'Arial, sans-serif';
Chart.defaults.plugins.legend.display = false; // Always use direct labels

const chart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: categories,
    datasets: [{
      data: values,
      backgroundColor: values.map((_, i) => i === highlightIndex ? '#1F77B4' : '#999999'),
      borderWidth: 0,
      borderRadius: 2,
    }]
  },
  options: {
    indexAxis: 'y',     // Horizontal bar
    responsive: true,
    plugins: {
      legend: { display: false },
      tooltip: { enabled: true },
    },
    scales: {
      x: {
        beginAtZero: true,   // ALWAYS zero baseline for bars
        grid: { display: false },
        border: { color: '#CCCCCC' },
        ticks: { color: '#595959' },
      },
      y: {
        grid: { display: false },
        border: { display: false },
        ticks: { color: '#595959' },
      }
    }
  }
});
```

---

## Quick Reminders (all libraries)

- Zero baseline on ALL bar charts
- No 3D chart types
- No pie/donut
- Remove top and right spines/borders
- Gridlines: off, or thin + light grey
- Legend: remove when direct labels are possible
- Colors: 1 accent + grey; don't use default rainbow palette
- Titles: action-oriented, left-aligned, dark grey (not black)
- Axis titles: always present (rare exception: when direct labels make them redundant)
- Annotate key data points with text callouts
