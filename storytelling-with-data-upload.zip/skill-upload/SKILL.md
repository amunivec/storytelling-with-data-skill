---
name: storytelling-with-data
description: >
  Apply Cole Nussbaumer Knaflic's "Storytelling with Data" principles whenever
  the user is working with data visualization, charts, data-driven narratives,
  or presentations. ALWAYS trigger this skill when the user asks to: create a
  chart or graph, recommend a chart type, write code that generates a visualization,
  critique or give feedback on an existing visual, improve a chart or dashboard,
  explain data to an audience, build a data dashboard, structure a data presentation,
  or tell a story with data. Also trigger when the user uploads or shares a chart
  image, asks "what's wrong with this?", "how do I improve this?", "is this a good
  chart?", or any variant. Also trigger for presentation structure, slide decks,
  storyboarding, or narrative flow for data communications. Use this skill
  proactively — even simple requests like "make a bar chart" or "review this visual"
  require applying these principles.
---

# Storytelling with Data Skill

Based on *Storytelling with Data* by Cole Nussbaumer Knaflic.

This skill governs how Claude approaches **all data visualization and data
communication work** — chart creation, code generation, visual critique, and
narrative structure. Every output must reflect the six core lessons below.

---

## The Six Core Lessons (apply in order)

### 1. Understand the Context First
Before choosing a chart or writing code, answer:
- **Who** is the audience? (specific person or group, not "everyone")
- **What** do you need them to know or do? (the call to action)
- **How** will it be consumed? (live presentation vs. circulated document)
- **What tone** is appropriate? (clinical, celebratory, urgent?)

Only use data that supports the message. Don't show exploratory analysis as
explanatory output — show the pearls, not all 100 oysters.

If context is missing, ask for it before proceeding. At minimum, establish who
the audience is and what action they should take.

### 2. Choose the Right Visual
Match the chart type to the communication need:

| Goal | Recommended chart |
|------|------------------|
| Single key number | **Simple text** — just the number + a few words |
| Look up values across categories | **Table** (use in reports, not live presentations) |
| Show relative magnitude across categories | **Heatmap** (table + color saturation) |
| Show trend over continuous time | **Line graph** |
| Compare two time points across categories | **Slopegraph** |
| Compare categorical values | **Horizontal bar chart** (preferred) or vertical bar |
| Show parts of a whole (absolute) | **Stacked bar** (use with caution) |
| Show starting point → changes → ending point | **Waterfall chart** |
| Show relationship between two variables | **Scatterplot** |
| Show numbers of vastly different magnitudes | **Square area graph** |

**Always avoid:**
- Pie and donut charts — humans can't accurately read angles or arc lengths
- 3D charts of any kind — they distort perception and add no information
- Secondary y-axes — confusing; use direct labels or separate charts instead
- Bar charts without a zero baseline — visually misleading

### 3. Eliminate Clutter
Every element added to a chart increases cognitive load. Remove anything that
doesn't add informative value.

**Remove by default:**
- Chart borders
- Background shading or fill
- Gridlines (or make them thin and grey if kept)
- Data markers on every point (use sparingly and on purpose)
- Trailing zeros on axis labels (e.g., `250.00` → `250`)
- Diagonal axis labels (rotate data or use horizontal bar chart instead)
- Legends when data can be labeled directly
- Redundant axis titles when data labels cover it

**Apply Gestalt principles:**
- **Proximity** — place labels next to the data they describe
- **Similarity** — use the same color for a label and its data series
- **Enclosure** — use light shading to group related data
- **Closure** — don't add chart borders; the brain completes the shape
- **Continuity** — remove axis lines when alignment is already clear from spacing
- **Connection** — use lines to show relationship; avoid disconnected elements

**Alignment and white space:**
- Left-justify text; avoid center alignment
- Avoid diagonal text
- Preserve margins — don't stretch visuals to fill space
- Don't add data just to fill white space

### 4. Focus the Audience's Attention
Use preattentive attributes to signal importance **before** the audience
consciously processes the chart.

**Hierarchy of attention (strongest to mildest):**
1. Color (hue, intensity) — most powerful
2. Size — larger = more important
3. Position (top-left of page = highest priority)
4. Bold / weight
5. Added marks (data points, callout labels)
6. Enclosure (boxes, shading)
7. Italics (mildest emphasis)

**Color rules:**
- Design in grey; use **one bold color** to draw attention
- Grey as base (not black) — allows greater contrast with the accent color
- Use blue for positive, orange for negative (avoids red/green colorblind issue)
- Never use color just for variety — color change signals meaning change
- Use consistent color coding throughout a communication
- Avoid red/green combinations (8% of men are colorblind)
- Keep color palette to 1–2 highlight colors max; everything else grey

**Size rules:**
- Use size to signal relative importance
- Items of equal importance should be equal size

**Position rules:**
- Most important content goes top-left — audiences scan in Z-patterns
- Put chart title, axis title, and legend upper-left before the data
- Don't make audiences read from bottom-to-top or right-to-left

### 5. Think Like a Designer
Form follows function. Design choices must serve the communication goal.

**Affordances (make the chart self-explanatory):**
- Highlight the important stuff (at most 10% of the visual)
- Eliminate distractions
- Create a clear visual hierarchy

**Accessibility (make it readable by anyone):**
- Every chart must have a title and axis titles (rare exceptions only)
- Label data series directly instead of using a legend
- Use action titles on slides ("Revenue declined 23% in Q3", not "Revenue")
- Annotate interesting or unusual points directly on the chart
- Use straightforward language; define acronyms

**Aesthetics:**
- Smart color use (intentional, sparse)
- Clean alignment (vertical and horizontal lines of elements)
- Strategic white space

**Text has a job in every visual:**
- Label: what is this?
- Explain: why does it matter?
- Highlight: what should I look at first?
- Annotate: what happened here?
- Call to action: what should I do?

### 6. Tell a Story
Data without narrative is just numbers. Structure every communication as:

**Beginning (Setup):**
- Set the context: When/where? Who is the main character (audience-framed)?
- Introduce the imbalance: What has changed or is at risk?
- State the desired balance: What should happen?

**Middle (Conflict):**
- Develop the problem with supporting data
- Include external context or comparison points
- Show consequences of inaction
- Build toward the recommendation

**End (Resolution — always a call to action):**
- State clearly what you need the audience to know or do
- Tie back to the imbalance introduced at the beginning

**Narrative tactics:**
- **Bing, Bang, Bongo**: Tell them what you'll say → say it → summarize
- **Horizontal logic**: Slide titles alone should tell the full story
- **Vertical logic**: Every element on a slide reinforces the slide's title
- **Lead with the ending** for trusted/busy audiences
- **Chronological order** when credibility needs to be established first

---

## Applying This to Code

When generating chart code (matplotlib, seaborn, Plotly, D3, etc.):

1. **Ask for context** if the audience/purpose is unclear
2. **Recommend the right chart type** before writing code; explain the reasoning
3. **Default color palette**: grey for non-focus elements, one accent color
4. **Remove defaults that add clutter**: chart borders, heavy gridlines, default
   color cycles, data markers on every point, default legends when direct labels work
5. **Always include**: chart title, axis titles, data source if known
6. **Label data directly** where possible instead of using a legend
7. **Annotate** key points that need explanation
8. **Set zero baseline** on all bar charts
9. **Never use 3D** chart types regardless of what is requested
10. **Never use pie/donut** charts — offer a bar chart alternative and explain why

### Code quality checklist (run mentally before output):
- [ ] Does the chart type match the communication goal?
- [ ] Is the baseline zero for bar charts?
- [ ] Is clutter removed (borders, gridlines, markers)?
- [ ] Is color used intentionally (grey base + one accent)?
- [ ] Are labels direct and horizontal?
- [ ] Is there a title and axis titles?
- [ ] Does the visual hierarchy guide the eye to the most important element first?

---

## Response Style

**Be brief by default.** Feedback, recommendations, and explanations should be
concise: one issue, one reason, one fix — per point. Do not write paragraphs
explaining principles unless the user asks for deeper explanation. A good
critique response is a tight list, not an essay.

**Always make a recommendation.** Never just identify a problem. Every issue
raised must close with a specific, actionable fix. "This is bad" without
"here's what to do instead" is not useful.

**Proactively flag bad practices.** If the user describes, mentions, or implies
a problematic approach — even if they didn't ask about it — call it out briefly
and recommend the alternative. Do not wait to be asked. Examples:
- User says "I'm using a pie chart" → flag it even if their question is about colors
- User mentions "3D bar chart" → flag it even if their question is about labels
- User says "I used rainbow colors" → flag it even if their question is about fonts
- User says "my axis starts at 50" on a bar chart → flag the misleading baseline
- User says "I have 15 charts on one dashboard" → flag cognitive overload

The pattern: answer the question asked, then add a brief "also worth noting:" for
any red flags observed in the description.

---

## Handling Common Requests

**"Make me a pie chart"**
→ Decline. One sentence reason (angles are hard to read). Recommend horizontal
bar chart instead.

**"Add more colors to make it pop"**
→ Decline. One sentence reason (everything different = nothing stands out).
Recommend grey base + one accent color on what matters most.

**"Can you make this 3D?"**
→ Decline. One sentence reason (3D distorts bar heights). Recommend flat 2D.

**"Show all the data"**
→ Ask: what do you need your audience to know or do? Show only what supports that.

**"Just a quick chart, no need to overthink it"**
→ Apply principles silently. Deliver clean output. No lecture unless asked.

---

## Critiquing Existing Visuals

When the user shares a chart image, dashboard screenshot, or describes an
existing visual and asks for feedback:

**Read `references/critique-mode.md` for the full audit checklist.**

**Default output format — keep it tight:**

```
**Needs fixing:**
- [Issue] — [one-line reason] → [specific fix]
- [Issue] — [one-line reason] → [specific fix]

**Also flag if present (even if not asked about):**
- [Proactive red flag] → [recommendation]

**What's working:**
- [Genuine strength — one line]

**Fix in this order:** [1, 2, 3]
```

Rules:
- Every issue gets a reason (one sentence max) and a fix
- Never skip "What's working" — even one genuine strength
- Never omit the priority order — always tell the user what to fix first
- Never just say "looks good" — if the chart is strong, say specifically why
  and note the next improvement

**Tool-specific red flags to proactively call out:**
- Excel / Power BI: 3D chart types, non-zero bar baseline, chart borders,
  heavy gridlines, default rainbow palette
- R (ggplot2): `theme_grey` background, legend instead of direct labels,
  raw column names as axis titles
- Python: default color cycle, small figure size, trailing decimal zeros
- Tableau / Power BI dashboards: too many charts per page (flag if >6),
  no clear primary question per page

---

## Building Data Narratives and Presentations

When the user is structuring a full presentation, report, or data communication
(not just a single chart):

**Read `references/narrative-structure.md` before responding.**

Quick protocol summary:

**Step 1 — Establish the Big Idea first**
A single sentence that: (1) states a unique point of view, (2) conveys what's
at stake, (3) is a complete sentence. If the user hasn't articulated this,
help them write it before touching slide structure.

**Step 2 — Storyboard before building**
Encourage sticky notes / paper over jumping into the tool. One idea per card.
Arrange until the headline sequence tells the full story.

**Step 3 — Three-act structure**
- Act 1 (Setup): context, main character framed as the audience, the imbalance
- Act 2 (Middle): evidence, options, consequences of inaction, the case for
  the recommendation
- Act 3 (End): call to action tied back to the opening imbalance

**Step 4 — Run the four story tests**
- Horizontal logic: titles alone tell the full story
- Vertical logic: every element on a slide reinforces its title
- Reverse storyboard: main points listed in order match intended story
- Fresh perspective: someone uninvolved can state what it's about

**Narrative flow choice:**
- Chronological: use when credibility needs establishing or audience is skeptical
- Lead with the ending: use when audience is trusted/busy; signal the structure
  explicitly ("I'm going to start with the ask, then walk you through the evidence")

---

## Cowork-Specific Instructions

Cowork has subagents, a persistent file system, and code execution. This enables
end-to-end chart workflows that aren't possible in Claude.ai chat. Apply the
same SWD principles as everywhere, but use Cowork's capabilities to go further.

### Environment Differences from Claude.ai

| Capability | Claude.ai | Cowork |
|---|---|---|
| Execute code and produce image files | No | Yes |
| Read uploaded CSV / Excel data files | Limited | Yes — `/mnt/user-data/uploads/` |
| Run before/after visual comparisons | No | Yes — generate both, present side-by-side |
| Parallel critique passes via subagents | No | Yes |
| Save outputs for download | No | Yes — `/mnt/user-data/outputs/` |
| Browser / display for chart preview | No | No — save to file, use `present_files` |

**Critical:** Cowork has no browser display. Never attempt to open or preview
a chart in a browser window. Always save chart output as an image file and
surface it via `present_files`.

---

### Workflow 1 — Generate Charts from Data Files

When the user provides a CSV, Excel, or other data file and asks for a chart:

**Step 1 — Read and profile the data**
```bash
# Inspect the file before writing any chart code
head -20 /mnt/user-data/uploads/data.csv
```
Or with Python:
```python
import pandas as pd
df = pd.read_csv('/mnt/user-data/uploads/data.csv')
print(df.shape)
print(df.dtypes)
print(df.head())
print(df.describe())
```

**Step 2 — Understand context before choosing chart type**
Ask (or infer from the file and conversation):
- Who is the audience?
- What decision or action should this chart support?
- Which columns are the signal vs. context?

**Step 3 — Choose the chart type** using the SWD principles above.
State your recommendation and reasoning before writing any code.

**Step 4 — Write and execute SWD-compliant chart code**
- Use `/mnt/user-data/outputs/` as the save path
- Save as PNG at 150 DPI minimum
- Apply the full SWD code quality checklist (see "Applying This to Code" above)

```python
# Always save to outputs, never display inline
fig.savefig('/mnt/user-data/outputs/chart.png', dpi=150, bbox_inches='tight')
plt.close()
```

**Step 5 — Present the file**
Use `present_files` to surface the saved image. Never skip this step —
the user cannot see the file without it.

**Step 6 — Explain the design decisions**
After presenting, briefly note: chart type chosen and why, what was
de-emphasized vs. highlighted, and any data quality issues noticed.

---

### Workflow 2 — Critique and Redesign Uploaded Chart Images

When the user uploads an existing chart image for review or redesign:

**Step 1 — Read the image**
```python
# Cowork can read image files directly
# The image will be at /mnt/user-data/uploads/<filename>
```
Use the `view` tool to inspect the image visually before writing anything.

**Step 2 — Run the full critique protocol**
Apply all six checks from `references/critique-mode.md`:
Context → Chart Type → Clutter → Attention/Hierarchy → Accessibility → Ethics

**Step 3 — Deliver the critique** in the structured format:
Critical → Significant → Minor → What's Working → Priority order

**Step 4 — If redesign is requested:**

4a. Ask about constraints if not already known:
- What tool will you use to implement this? (Excel, Python, R, Tableau, etc.)
- Are there brand colors to respect?
- Is the data available for me to work with?

4b. If data is available, produce the redesign as a new image file:
```python
# Generate redesigned chart
fig, ax = plt.subplots(figsize=(10, 6))
# ... SWD-compliant code ...
fig.savefig('/mnt/user-data/outputs/chart_redesigned.png', dpi=150, bbox_inches='tight')
plt.close()
```

4c. If data is not available, produce annotated guidance instead —
describe exactly what changes to make and why, organized by tool
(e.g., "In Excel: right-click chart border → Format Chart Area → No fill,
No line").

4d. **Before/after comparison** — when both original and redesign exist,
create a side-by-side comparison image:
```python
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

original = mpimg.imread('/mnt/user-data/uploads/original_chart.png')
redesign = mpimg.imread('/mnt/user-data/outputs/chart_redesigned.png')

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 7))
ax1.imshow(original); ax1.axis('off'); ax1.set_title('Before', fontsize=13, color='#595959')
ax2.imshow(redesign); ax2.axis('off'); ax2.set_title('After (SWD principles)', fontsize=13, color='#595959')

plt.tight_layout()
fig.savefig('/mnt/user-data/outputs/before_after.png', dpi=150, bbox_inches='tight')
plt.close()
```

**Step 5 — Present all output files** via `present_files`. If a before/after
comparison was made, present it first — it's the most useful artifact.

---

### Workflow 3 — Build Full Presentation Decks from Data

When the user wants a complete data presentation, not just individual charts:

**Step 1 — Establish the Big Idea and storyboard first**
Do not generate any charts or slides until:
- The Big Idea sentence is written and confirmed
- The slide sequence (storyboard) is agreed on

Present the storyboard as a numbered list of action titles and get approval
before proceeding. This prevents wasted chart generation.

**Step 2 — Generate charts in parallel via subagents**
Each chart in the deck can be generated as a separate subagent task.
Use consistent naming: `slide_01_chart.png`, `slide_02_chart.png`, etc.
All charts in a deck must use the same color palette — establish it once
and pass it to every subagent explicitly.

**Step 3 — Assemble the deck**
Options depending on the user's tool:
- **Python (matplotlib multi-panel):** Combine charts into a single PDF
  or a series of slide-sized PNG images (1920×1080px at 96 DPI)
- **PowerPoint (.pptx):** Use the `python-pptx` library to build a deck
  programmatically with charts embedded and action titles set
- **Export to tool:** Deliver chart images + a slide outline document
  the user can assemble manually in their preferred tool

```python
# Slide-sized chart output (16:9)
fig = plt.figure(figsize=(19.2, 10.8))  # 1920x1080 at 100dpi
# ... chart code ...
fig.savefig('/mnt/user-data/outputs/slide_01_chart.png', dpi=100, bbox_inches='tight')
```

**Step 4 — Run the story tests before presenting**
Before delivering the final deck:
- Confirm horizontal logic: do the action titles tell the story in sequence?
- Confirm vertical logic: does each chart support its slide's title?
- Note any slides where the chart and title are misaligned

**Step 5 — Present all output files** via `present_files`, deck file first,
individual chart images after.

---

### Cowork Quality Checklist

Before calling `present_files` on any output, verify:

- [ ] All chart images saved to `/mnt/user-data/outputs/` (not `/tmp/` or elsewhere)
- [ ] Image resolution is 150 DPI or higher
- [ ] No chart uses a pie, donut, or 3D type
- [ ] All bar charts have zero baseline
- [ ] Color palette is grey base + max 2 accent colors
- [ ] Every chart has a title and axis titles
- [ ] Legends replaced with direct labels where possible
- [ ] `present_files` called — file is invisible to the user until this runs
- [ ] Design decisions briefly explained after presenting

---

## Reference

For deeper guidance, read the relevant reference file:
- `references/chart-types.md` — when to use each chart type, with decision rules
- `references/color-guide.md` — color palette templates and colorblind-safe choices
- `references/code-templates.md` — starter code for clean charts in common libraries
- `references/critique-mode.md` — systematic audit protocol for existing charts
- `references/narrative-structure.md` — Big Idea, storyboarding, three-act structure,
  presentation flow tests
